# ProjetoJavaConversor

Projeto Java 17 com Spring Boot para conversão de moedas, utilizando uma API externa de câmbio.

- Provedor principal: [currencylayer](https://currencylayer.com/) (requer `access_key`)
- Fallback: [exchangerate.host](https://exchangerate.host/)
- Frontend estático servido a partir de `src/main/resources/static/`

## Requisitos

- Java 17
- Maven 3.x
- Acesso à internet para consumir as APIs de câmbio

## Configuração da chave da currencylayer

**Não** coloque a chave (`access_key`) diretamente no código ou repositório.

Use uma variável de ambiente:

```bash
export CURRENCYLAYER_API_KEY="SUA_CHAVE_AQUI"
```

Ou passe via linha de comando Maven/Spring Boot:

```bash
mvn spring-boot:run -Dspring-boot.run.jvmArguments="-DCURRENCYLAYER_API_KEY=SUA_CHAVE_AQUI"
```

Também é possível configurar a propriedade `currencylayer.access-key` através de mecanismos seguros (por exemplo,
`application-*.properties` fora do controle de versão). No arquivo `application.properties` deste projeto existe
apenas uma referência placeholder:

```properties
currencylayer.access-key=${CURRENCYLAYER_API_KEY:}
```

Se nenhuma chave for configurada, o serviço tentará usar **apenas** o fallback `exchangerate.host`.

## Como executar o projeto

1. Clonar ou extrair o ZIP do projeto.
2. Entrar na pasta raiz:

   ```bash
   cd ProjetoJavaConversor
   ```

3. (Opcional) Configurar a variável de ambiente com a chave da currencylayer:

   ```bash
   export CURRENCYLAYER_API_KEY="SUA_CHAVE_AQUI"
   ```

4. Compilar e executar:

   ```bash
   mvn spring-boot:run
   ```

5. Acessar o frontend em:

   - <http://localhost:8080/>

   O backend expõe o endpoint de conversão em:

   - `GET /api/convert?from=USD&to=BRL&amount=10`

## Estrutura principal

```text
ProjetoJavaConversor/
├── pom.xml
├── README.md
└── src
    └── main
        ├── java
        │   └── com
        │       └── example
        │           └── projetojavaconversor
        │               ├── ProjetoJavaConversorApplication.java
        │               ├── controller
        │               │   └── CurrencyConversionController.java
        │               ├── dto
        │               │   └── ConversionResponse.java
        │               └── service
        │                   └── CurrencyConversionService.java
        └── resources
            ├── application.properties
            └── static
                └── index.html
```

## Notas sobre a implementação

- O serviço tenta primeiro usar o provedor **currencylayer** (`/live`),
  retornando `null` caso não haja chave configurada ou ocorra erro na requisição.
- Em seguida, tenta o fallback **exchangerate.host** (`/convert`).
- Se nenhum provedor retornar uma taxa válida, é lançada uma exceção informando que não foi possível obter a taxa.
- O frontend simples em `index.html` consome o endpoint `/api/convert` e exibe o resultado de forma amigável.
