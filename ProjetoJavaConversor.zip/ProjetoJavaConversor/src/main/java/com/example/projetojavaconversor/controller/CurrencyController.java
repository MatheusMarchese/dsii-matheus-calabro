package com.example.projetojavaconversor.controller;

import com.example.projetojavaconversor.service.CurrencyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class CurrencyController {

    @Autowired
    private CurrencyService currencyService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @GetMapping("/converter")
    public String converter(
            @RequestParam double valor,
            @RequestParam String origem,
            @RequestParam String destino,
            Model model
    ) {
        double taxa = currencyService.getRate(origem, destino);
        double resultado = valor * taxa;

        model.addAttribute("resultado", resultado);
        model.addAttribute("taxa", taxa);
        model.addAttribute("origem", origem);
        model.addAttribute("destino", destino);

        return "index";
    }
}