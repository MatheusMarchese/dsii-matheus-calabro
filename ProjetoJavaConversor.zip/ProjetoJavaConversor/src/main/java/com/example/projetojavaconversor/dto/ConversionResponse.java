package com.example.projetojavaconversor.dto;

import java.math.BigDecimal;

public class ConversionResponse {

    private String from;
    private String to;
    private BigDecimal amount;
    private BigDecimal rate;
    private BigDecimal convertedAmount;
    private String provider;

    public ConversionResponse(String from, String to, BigDecimal amount, BigDecimal rate, BigDecimal convertedAmount, String provider) {
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.rate = rate;
        this.convertedAmount = convertedAmount;
        this.provider = provider;
    }

    public String getFrom() {
        return from;
    }

    public String getTo() {
        return to;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public BigDecimal getRate() {
        return rate;
    }

    public BigDecimal getConvertedAmount() {
        return convertedAmount;
    }

    public String getProvider() {
        return provider;
    }
}
