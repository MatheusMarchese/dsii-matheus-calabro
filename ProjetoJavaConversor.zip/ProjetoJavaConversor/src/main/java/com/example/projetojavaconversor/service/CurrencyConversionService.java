package com.example.projetojavaconversor.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Map;

@Service
public class CurrencyConversionService {

    @Value("${currencylayer.base-url:http://api.currencylayer.com}")
    private String currencyLayerBaseUrl;

    @Value("${currencylayer.access-key:}")
    private String currencyLayerAccessKey;

    @Value("${exchangeratehost.base-url:https://api.exchangerate.host}")
    private String exchangeRateHostBaseUrl;

    private final RestTemplate restTemplate = new RestTemplate();

    public BigDecimal convert(String from, String to, BigDecimal amount) {
        BigDecimal rate = getRateFromCurrencyLayer(from, to);
        if (rate == null) {
            rate = getRateFromExchangeRateHost(from, to);
        }
        if (rate == null) {
            throw new IllegalStateException("Não foi possível obter a taxa de câmbio de nenhum provedor.");
        }
        return amount.multiply(rate).setScale(4, RoundingMode.HALF_UP);
    }

    private BigDecimal getRateFromCurrencyLayer(String from, String to) {
        if (currencyLayerAccessKey == null || currencyLayerAccessKey.isBlank()) {
            return null;
        }
        try {
            // currencylayer normalmente trabalha com USD como base no plano gratuito.
            // Neste exemplo, usamos a rota /live e ajustamos se necessário.
            String url = String.format("%s/live?access_key=%s&currencies=%s&source=%s&format=1",
                    currencyLayerBaseUrl, currencyLayerAccessKey, to.toUpperCase(), from.toUpperCase());

            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                return null;
            }
            Map body = response.getBody();
            Object success = body.get("success");
            if (success instanceof Boolean && !((Boolean) success)) {
                return null;
            }
            Object quotesObj = body.get("quotes");
            if (!(quotesObj instanceof Map)) {
                return null;
            }
            Map quotes = (Map) quotesObj;
            String key = from.toUpperCase() + to.toUpperCase();
            Object rateObj = quotes.get(key);
            if (rateObj instanceof Number) {
                return new BigDecimal(rateObj.toString());
            }
            return null;
        } catch (RestClientException ex) {
            return null;
        }
    }

    private BigDecimal getRateFromExchangeRateHost(String from, String to) {
        try {
            String url = String.format("%s/convert?from=%s&to=%s",
                    exchangeRateHostBaseUrl, from.toUpperCase(), to.toUpperCase());
            ResponseEntity<Map> response = restTemplate.getForEntity(url, Map.class);
            if (!response.getStatusCode().is2xxSuccessful() || response.getBody() == null) {
                return null;
            }
            Map body = response.getBody();
            Object success = body.get("success");
            if (success instanceof Boolean && !((Boolean) success)) {
                return null;
            }
            Object resultObj = body.get("result");
            if (resultObj instanceof Number) {
                return new BigDecimal(resultObj.toString());
            }
            return null;
        } catch (RestClientException ex) {
            return null;
        }
    }
}
