package com.example.projetojavaconversor.service;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

@Service
public class CurrencyService {

    private static final String API_KEY = "3079746ee725850a0e83bdf9";

    public double getRate(String origem, String destino) {

        try {
            String urlStr = "https://v6.exchangerate-api.com/v6/"
                    + API_KEY + "/pair/" + origem + "/" + destino;

            URL url = new URL(urlStr);
            HttpURLConnection request = (HttpURLConnection) url.openConnection();
            request.connect();

            InputStream response = request.getInputStream();
            String json = new String(response.readAllBytes(), StandardCharsets.UTF_8);

            JSONObject obj = new JSONObject(json);

            System.out.println("RESPOSTA API -> " + obj);

            return obj.getDouble("conversion_rate");

        } catch (Exception e) {
            e.printStackTrace();
            return 1;
        }
    }
}