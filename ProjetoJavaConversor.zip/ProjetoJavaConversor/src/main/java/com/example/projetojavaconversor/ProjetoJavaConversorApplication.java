package com.example.projetojavaconversor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoJavaConversorApplication {

    public static void main(String[] args) {
        SpringApplication.run(ProjetoJavaConversorApplication.class, args);
    }
}